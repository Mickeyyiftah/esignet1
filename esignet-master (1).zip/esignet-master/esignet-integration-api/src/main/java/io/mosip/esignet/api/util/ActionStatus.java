package io.mosip.esignet.api.util;

public enum ActionStatus {

    SUCCESS,
    ERROR
}
