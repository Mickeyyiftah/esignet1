package io.mosip.esignet.api.util;

public enum ConsentAction {
    CAPTURE,
    NOCAPTURE,
}
