## Binding Service

## Databases
Refer to [SQL scripts](db_scripts/mosip_esignet).

## License
This project is licensed under the terms of [Mozilla Public License 2.0](LICENSE).
