\c mosip_esignet

\ir ddl/esignet-client_detail.sql
\ir ddl/esignet-key_alias.sql
\ir ddl/esignet-key_policy_def.sql
\ir ddl/esignet-key_store.sql
\ir ddl/esignet-public_key_registry.sql
\ir ddl/esignet-consent.sql
\ir ddl/esignet-consent_history.sql
