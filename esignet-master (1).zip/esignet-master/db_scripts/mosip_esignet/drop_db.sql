DROP DATABASE IF EXISTS mosip_esignet;

