drop role if exists esignetuser;
