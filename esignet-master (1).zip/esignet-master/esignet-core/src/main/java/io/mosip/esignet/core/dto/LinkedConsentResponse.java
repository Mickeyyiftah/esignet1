package io.mosip.esignet.core.dto;

import lombok.Data;

@Data
public class LinkedConsentResponse {
    private String linkedTransactionId;
}
