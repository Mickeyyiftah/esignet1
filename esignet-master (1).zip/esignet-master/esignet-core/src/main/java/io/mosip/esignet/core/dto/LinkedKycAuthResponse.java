package io.mosip.esignet.core.dto;

import lombok.Data;

@Data
public class LinkedKycAuthResponse {
    private String linkedTransactionId;
}
