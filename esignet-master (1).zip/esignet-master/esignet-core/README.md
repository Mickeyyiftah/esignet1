# e-Signet Core Library
