import React from "react";
import EsignetDetails from "../components/EsignetDetails";

export default function EsignetDetailsPage() {
  return <EsignetDetails />;
}
