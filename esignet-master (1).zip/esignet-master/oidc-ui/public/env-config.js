window._env_ = {
  DEFAULT_LANG: "en",
  DEFAULT_WELLKNOWN: "%5B%7B%22name%22%3A%22OpenID%20Configuration%22%2C%22value%22%3A%22%2F.well-known%2Fopenid-configuration%22%7D%2C%7B%22name%22%3A%22Jwks%20Json%22%2C%22value%22%3A%22%2F.well-known%2Fjwks.json%22%7D%2C%7B%22name%22%3A%22Authorization%20Server%22%2C%22value%22%3A%22%2F.well-known%2Foauth-authorization-server%22%7D%2C%7B%22name%22%3A%22OpenID%20Credential%20Issuer%22%2C%22value%22%3A%22%2F.well-known%2Fopenid-credential-issuer%22%7D%5D",
  DEFAULT_THEME: '',
  DEFAULT_FEVICON: 'favicon.ico',
  DEFAULT_TITLE: 'e-Signet',
  DEFAULT_ID_PROVIDER_NAME: 'e-Signet'
};
