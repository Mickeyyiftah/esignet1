# Redis

* The open source, in-memory data store used by millions of developers as a database, cache, streaming engine, and message broker.
* In IDP we are using Redis as a cache store.

## Install
```
$ ./install.sh
```
## Delete
```
$ ./delete.sh
```
