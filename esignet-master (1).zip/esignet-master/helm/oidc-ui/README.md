# oidc-ui

## Overview
Refer [Commons](https://docs.mosip.io/1.2.0/modules/commons).

## Install 
```
./install.sh
```


